package com.codefundo.vote;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class AuthSuccessScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_auth_success_screen);
    }
}
